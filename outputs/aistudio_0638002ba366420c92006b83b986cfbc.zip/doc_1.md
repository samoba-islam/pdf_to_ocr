# www.exambd.net

১২.4 সে.মি. বাছবিশিষ্ট বর্গক্ষেত্রে পরিলিখিত বৃত্তের ক্ষেত্রফল কত?

ক. 8π বর্ণ সে.মি.

খ. 6π বর্ণ সে.মি.

গ.4π বর্ণ সে.মি.

ঘ. 2√2π বর্ণ সে.মি.

পৃষ্ঠা: ৮৩১ এর ২৫৭ নম্বরের অনুরূপ (অগ্রদূত Basic Math, January-2024 Edition)

১৩.CONIC শব্দটির অক্ষরগুলো নিয়ে গঠিত বিন্যাস সংখ্যা কত?

ক. 24 খ. 40

গ. 60 ঘ. 120 উ. গ

পৃষ্ঠা: ৭০০ এর ১২৪ নম্বরের অনুরূপ (অগ্রদূত Basic Math, January-2024 Edition)

১৪.যদি A = {x : x হলো 5, 7 ঘারা বিভাজ্য এবং x < 150} হয় তবে P(A) এর সদস্য সংখ্যা কত?

ক. 8          খ. 12

গ. 14          ঘ. 16          উ. ঘ

পৃষ্ঠা: ৬৭২ এর ৩২ নম্বরের অনুরূপ (অগ্রদূত Basic Math, January-2024 Edition)

১৫. একটি থলিতে 5টি নীল, 10টি সাদা, 20টি কালো বল আছে। দৈব চয়নের মাধ্যমে একটি বল তুললে সেটি সাদা না হওয়ার সম্ভাবনা কত?

ক.  $ \frac{3}{10} $ খ.  $ \frac{5}{7} $

গ.  $ \frac{7}{5} $ ঘ.  $ \frac{7}{10} $ উ. খ

পৃষ্ঠা: ৭১৩ এর ৩০ নমরের অনুরূপ (অগ্রদূত Basic Math, January-2024 Edition)

১৬.একজন লোক উতর-পশ্চম দিকে মুখ করে আছে। সে ঘড়ির

কাঁটার দিকে ৯০° ঘুরে, তারপরে ঘড়ির কাঁটার বিপরীত

দিকে ১৮০° ঘুরে এবং তারপর একই দিকে আরো ৯০°

ঘুরে। এখন সে কোন দিকে মুখ করে আছে?

ক. দক্ষণ  খ. দক্ষণ-পশ্চম

গ. দক্ষণ-পূর্ব  ঘ. পূর্ব  উ. গ

১৭. নিম্নের শব্দগুলো অভিধানে যে ক্রমে আছে সেভাবে সাজান-

১. Protect

৩. Pastel

৫. Pebble

ক.৪৩৫২১

গ. ৩৪৫১২

ঘ. ৩৫৪২১

ঘ. ৪৩৫১২

উ. খ

১৮.একটি ছবিতে একজন পুরুষের দিকে ইঙ্গিত করে একজন মহিলা বলেন, “তার ভাইয়ের বাবা আমার দাদার একমাত্র ছেলে।” ছবির পুরুষের সঙ্গে উক্ত মহিলার সম্পর্ক কী?

ক. মা  খ. খালা  অগ্রদূত Recent Job Solution

গ. বোন  ঘ. কন্যা  উ. গ



১৯. যদি E = 10, J = 20, O = 30 এবৎ T = 40 হয়,

তাহলে B + E + S + T = ?

ক. ৭১

গ. ৯০

খ. ৮২

ঘ. ৯২

উ. ঘ

২০. নিচের কোন শব্দটি অন্যদের থেকে আলাদা?

ক. Kiwi          খ. Eagle

গ. Emu          ঘ. Ostrich          উ. খ

২১.একজন  মহিলা  বলেছেন,  “আপনি  যদি  আমার  নিজের  বয়সকে  উল্টে  দেন  তাহলে  তা  আমার  স্বামীর  বয়সকে  নির্দেশ  করে।  তিনি  আমার  থেকে  বয়সে  বড়  এবং  আমাদের  বয়সের  পার্থক্য  আমাদের  মোট  বয়সের  যোগফলের  এগারো  ভাগের  একভাগ।”  মহিলার  বয়স  কত?

ক.  ২৩  বছর

গ.  ৪৫  বছর

খ.  ৩৪  বছর

ঘ.  কোনোটিই নয়

উ.  গ

২২.যদি একটি কামান থেকে নিম্নলিখিত ৪টি বস্তুকে অনুভূমিক

ভাবে নিক্ষেপ করা হয়, তবে কোনটি সবচেয়ে বেশি দূরে

উড়ে যাবে?

ゆ.

<div style="text-align: center;"><img src="imgs/img_in_image_box_674_680_778_707.jpg" alt="Image" width="8%" /></div>


각.

 $ π $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_890_680_992_719.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_670_729_726_778.jpg" alt="Image" width="4%" /></div>


ཡ.

<div style="text-align: center;"><img src="imgs/img_in_image_box_891_730_940_774.jpg" alt="Image" width="4%" /></div>


২৩.একটি সভায় ১৫ জন লোক রয়েছে এবং তারা সকলেই সভা

শেষে  একে  অপরের  সাথে  করমর্দন  করে।  মোট  কতটি

করমর্দন হবে?

ক. ২১০

গ. ২২৫

খ. ১০৫

ঘ. ১৯৬

উ. খ

২৪.সেই  জুটি  নির্বাচন  করুন  যা  “Children :  pediatrician” জুটির  মধ্যে  প্রকাশিত  সম্পর্কটির  মতো  একটি  সম্পর্ককে  সর্বোত্তমভাবে  প্রকাশ  করে।

ক. Adult : Orthopedist

খ. Kidney : Nephrologist

গ. Females : Gynecologist

ঘ. Skin : Darmatologist  উ. গ

২৫. কোন চিত্রটি সিরিজটি সম্পূর্ণ করে?

<div style="text-align: center;"><img src="imgs/img_in_image_box_647_1196_750_1284.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_757_1196_859_1284.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_867_1195_970_1284.jpg" alt="Image" width="8%" /></div>


ゆ.

<div style="text-align: center;"><img src="imgs/img_in_image_box_977_1194_1081_1281.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_670_1293_773_1383.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_886_1293_989_1382.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_670_1387_773_1476.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_886_1387_990_1477.jpg" alt="Image" width="8%" /></div>


প্রতি মাসের ১-৩০ তারিখ পর্যন্ত অনুষ্ঠিত সকল চাকরির

পরীক্ষার প্রশ্নের ব্যাখ্যাসহ নির্ভুল সমাধানের জন্য পড়ুন-

‘অগ্রদৃত মাসিক পরিক্রমা’